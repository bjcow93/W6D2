class View {
  constructor(game, $el) {
    this.game = game;
    this.$el = $el;

    this.setupBoard();
    this.bindEvents();
    this.game.play();
  }

  bindEvents() {
    // bind a click handler to each #square that calls press()
    this.$el.on('click', '#square', (e) => {
      let $square = $(e.target);
      this.press($square);
    });
  }

  static flash($square) {
    // class function that removes css classes and then adds them back
    // capture color of square
    // data with 1 arg = getter, with 2 args = setter
    let color = $square.data('color');
    // change color to white
    $square.removeClass();
    $square.addClass('flash');
    // undo after .5 seconds
    setTimeout(() => {
      $square.removeClass();
      $square.addClass(color);
    }, 500);
  }

  press($square) {
    // calls flash() and adds to guesses and calls game's check()
    let color = $square.data('color');
    this.game.guesses.push(color);
    this.game.check();
    View.flash($square);

  }

  setupBoard() {
    // populates the root element with a $board containing squares
    // add .black class to $board
    // add data for color for each square

    const $board = $("<div>");

    $board.addClass('black');
    const colors = ['green', 'red', 'yellow', 'blue'];
    for (var i = 0; i < colors.length; i++) {
      let $square = $("<div>");
      // Adds an html attribute (name, value, id, class, etc.)
      $square.attr('id', 'square');
      // Add key-value pair for data you want to store with information
      // about the element. Not an html attribute. Also is not
      // visible by the browser in the DOM.
      $square.data('color', colors[i]);
      $square.addClass(colors[i]);
      $board.append($square);
    }

    this.$el.append($board);
  }
}

module.exports = View;
